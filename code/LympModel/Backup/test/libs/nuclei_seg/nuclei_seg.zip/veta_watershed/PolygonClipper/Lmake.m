		mex gpc.c gpc_mexfile.c -O -output polyclip              % optimized
